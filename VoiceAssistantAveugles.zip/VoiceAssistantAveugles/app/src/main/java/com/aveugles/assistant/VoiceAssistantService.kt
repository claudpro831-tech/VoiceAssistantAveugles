package com.aveugles.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * خدمة تعمل في الخلفية بشكل دائم:
 * تستمع للأوامر الصوتية، تحوّلها إلى نص، ثم تمررها إلى CommandProcessor لتنفيذها.
 *
 * ملاحظة مهمة: SpeechRecognizer من أندرويد لا يدعم "wake word" حقيقي بدون اتصال دائم بالإنترنت
 * ودورة استماع متكررة. للحصول على كلمة تنشيط تعمل دون اتصال (offline wake word مثل "يا مساعد")
 * يُنصح لاحقًا بدمج مكتبة مثل Porcupine (Picovoice). هنا نبني دورة استماع مستمرة عبر
 * SpeechRecognizer كأساس يعمل فورًا، ويمكن استبدالها لاحقًا بمحرك wake word مخصص.
 */
class VoiceAssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceAssistantService"
        private const val CHANNEL_ID = "voice_assistant_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var commandProcessor: CommandProcessor
    private var isListening = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        commandProcessor = CommandProcessor(this) { textToSpeak -> speak(textToSpeak) }
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        startListeningLoop()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ar"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "اللغة العربية غير مدعومة بالكامل في TTS على هذا الجهاز")
            }
            speak("المساعد الصوتي جاهز")
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utterance_${System.currentTimeMillis()}")
    }

    /** يبدأ دورة استماع مستمرة: يستمع، يعالج الأمر، ثم يعيد الاستماع تلقائيًا. */
    private fun startListeningLoop() {
        if (isListening) return
        isListening = true
        listenOnce()
    }

    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "التعرف على الكلام غير متوفر على هذا الجهاز")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                Log.w(TAG, "خطأ في التعرف على الكلام: $error")
                // أعد المحاولة بعد فشل أو صمت، حتى تبقى الخدمة "دائمة الاستماع"
                restartListening()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull()
                if (!spokenText.isNullOrBlank()) {
                    Log.d(TAG, "تم التعرف على: $spokenText")
                    commandProcessor.process(spokenText)
                }
                restartListening()
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun restartListening() {
        // مهلة بسيطة قبل إعادة الاستماع لتجنب حلقة سريعة جدًا تستهلك المعالج والبطارية
        android.os.Handler(mainLooper).postDelayed({ listenOnce() }, 800)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("المساعد يستمع الآن")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "المساعد الصوتي",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isListening = false
        speechRecognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
