package com.aveugles.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log

/**
 * يحلل النص المنطوق (بعد التعرف على الكلام) ويحدد نية المستخدم:
 * اتصال، فتح تطبيق، أو كتابة نص. قابل للتوسعة بسهولة بإضافة أنماط جديدة.
 */
class CommandProcessor(
    private val context: Context,
    private val onFeedback: (String) -> Unit
) {
    companion object {
        private const val TAG = "CommandProcessor"
    }

    private val callTriggers = listOf("اتصل ب", "اتصل على", "كلم")
    private val openTriggers = listOf("افتح", "شغل")
    private val writeTriggers = listOf("اكتب", "أكتب")

    fun process(spokenText: String) {
        val text = spokenText.trim()

        when {
            callTriggers.any { text.startsWith(it) } -> {
                val target = stripFirstTrigger(text, callTriggers)
                handleCall(target)
            }
            openTriggers.any { text.startsWith(it) } -> {
                val target = stripFirstTrigger(text, openTriggers)
                handleOpenApp(target)
            }
            writeTriggers.any { text.startsWith(it) } -> {
                val target = stripFirstTrigger(text, writeTriggers)
                handleWriteText(target)
            }
            else -> {
                onFeedback("لم أفهم الأمر، حاول مرة أخرى")
            }
        }
    }

    private fun stripFirstTrigger(text: String, triggers: List<String>): String {
        val trigger = triggers.first { text.startsWith(it) }
        return text.removePrefix(trigger).trim()
    }

    // ---------- الاتصال ----------
    private fun handleCall(contactName: String) {
        if (contactName.isBlank()) {
            onFeedback("قل اسم الشخص الذي تريد الاتصال به")
            return
        }
        val phoneNumber = findPhoneNumberByName(contactName)
        if (phoneNumber == null) {
            onFeedback("لم أجد جهة اتصال باسم $contactName")
            return
        }
        try {
            val callIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(callIntent)
            onFeedback("جارٍ الاتصال بـ $contactName")
        } catch (e: SecurityException) {
            Log.e(TAG, "صلاحية الاتصال غير ممنوحة", e)
            onFeedback("لا أملك صلاحية إجراء المكالمات")
        }
    }

    private fun findPhoneNumberByName(name: String): String? {
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIndex)
            }
        }
        return null
    }

    // ---------- فتح التطبيقات ----------
    private fun handleOpenApp(appName: String) {
        if (appName.isBlank()) {
            onFeedback("قل اسم التطبيق الذي تريد فتحه")
            return
        }
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        val match = installedApps.firstOrNull { appInfo ->
            val label = pm.getApplicationLabel(appInfo).toString()
            label.contains(appName, ignoreCase = true) || appName.contains(label, ignoreCase = true)
        }

        if (match == null) {
            onFeedback("لم أجد تطبيق $appName")
            return
        }

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            onFeedback("جارٍ فتح ${pm.getApplicationLabel(match)}")
        } else {
            onFeedback("لا يمكن فتح هذا التطبيق")
        }
    }

    // ---------- الكتابة ----------
    private fun handleWriteText(content: String) {
        if (content.isBlank()) {
            onFeedback("قل النص الذي تريد كتابته")
            return
        }
        val injected = TextInjectionAccessibilityService.instance?.injectText(content)
        if (injected == true) {
            onFeedback("تم كتابة النص")
        } else {
            onFeedback("يجب تفعيل خدمة إمكانية الوصول أولاً من إعدادات الهاتف، وفتح حقل كتابة نشط")
        }
    }
}
