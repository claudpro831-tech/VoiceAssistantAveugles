package com.aveugles.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * خدمة إمكانية الوصول: تسمح بحقن نص في أي حقل إدخال نشط حاليًا (رسالة، بحث، أي تطبيق)
 * وأيضًا قراءة محتوى الشاشة إذا احتجنا لاحقًا. يجب على المستخدم تفعيلها يدويًا من
 * إعدادات > إمكانية الوصول > المساعد الصوتي (خطوة واحدة لمرة واحدة).
 */
class TextInjectionAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TextInjectionAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // يمكن لاحقًا استخدام هذا لقراءة محتوى الشاشة تلقائيًا عند تغيّره
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * يبحث عن حقل الإدخال الذي يحمل التركيز حاليًا (Focused Editable Node) في أي تطبيق مفتوح
     * ويكتب فيه النص المعطى. يعيد true إذا نجحت العملية.
     */
    fun injectText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focusedNode = findFocusedEditableNode(root) ?: return false

        val arguments = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    private fun findFocusedEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFocusedEditableNode(child)
            if (result != null) return result
        }
        return null
    }
}
