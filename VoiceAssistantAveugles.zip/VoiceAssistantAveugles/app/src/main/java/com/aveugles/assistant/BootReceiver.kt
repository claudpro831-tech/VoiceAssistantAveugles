package com.aveugles.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * يعيد تشغيل خدمة المساعد الصوتي تلقائيًا بعد إعادة إقلاع الهاتف،
 * حتى يبقى المساعد جاهزًا دائمًا للمستخدم الكفيف دون الحاجة لفتح التطبيق يدويًا.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val serviceIntent = Intent(context, VoiceAssistantService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
        }
    }
}
